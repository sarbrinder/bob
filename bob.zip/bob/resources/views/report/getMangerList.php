<?php for($i=0;$i<count($id);$i++) {?>
<option value="<?php echo $id[$i];?>"><?php echo $fName[$i] . ' ' . $lName[$i];?></option>
<?php } ?> 