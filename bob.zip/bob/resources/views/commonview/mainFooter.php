<script type="text/javascript" src="<?php echo asset('public/js/jquery.min.js')?>" ></script>

<script type="text/javascript" src="<?php echo asset('public/js/jquery.form.js')?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.0.4/popper.js"></script>
<script type="text/javascript" src="<?php echo asset('public/js/bootstrap.min.js')?>" ></script>
<script type="text/javascript" src="<?php echo asset('public/js/editor.js')?>"></script>
<script type="text/javascript" src="<?php echo asset('public/js/jquery-ui.js')?>" ></script>
<!--<script type="text/javascript" src="<?php //echo asset('public/js/jquery-ui.min.js')?>" ></script>-->
<script type="text/javascript" src="<?php echo asset('public/js/urlActivation.js')?>"></script>
<!--<script type="text/javascript" src="http://yourhelpgroup.com/forex/assets/js/error.js"></script>-->
<script type="text/javascript" src="<?php echo asset('public/js/common.js')?>"></script>
<!--<script type="text/javascript" src="http://yourhelpgroup.com/forex/assets/js/client.js"></script>-->


<!--<script type="text/javascript" src="http://yourhelpgroup.com/forex/clientassets/js/mycustom.js"></script>-->
<!-- by raman-->

<script src=" <?php echo asset('public/js/chartist.min.js')?>"></script>
<script src="<?php echo asset('public/js/arrive.min.js')?>"></script>
<script src="<?php echo asset('public/js/perfect-scrollbar.jquery.min.js')?>"></script>
<script src="<?php echo asset('public/js/demo.js')?>"></script>
<script src="<?php echo asset('public/js/custom.js')?>"></script>
<!----->
<script>
			$(document).ready(function() {
				$("#txtEditor").Editor();
			});
		</script>